﻿(function () {
    let positions = [];
    let unit = 50;
    const cmulti = 1.7;
    window.addEventListener("resize", (event) => {
        calcPositions();
        showDots();
    });

    function calcPositions() {
        positions = [];
        let board = document.getElementById("board");
        let offsetX = board.height;
        let offsetY = offsetX;
        unit = offsetY / 12.41;
        for (let i = 0; i < 40; i++) {
            if (i == 0) {
                positions.push({
                    pos: i,
                    x: offsetX - (unit * cmulti) / 2,
                    y: offsetY - (unit * cmulti) / 2
                });
                offsetX -= unit * 1.7;
            }
            if (i > 0 && i < 10) {
                positions.push({
                    pos: i,
                    x: offsetX - unit / 2,
                    y: offsetY - (unit * cmulti) / 2
                });
                offsetX -= unit;
            }
            if (i == 10) {
                positions.push({
                    pos: i,
                    x: unit * cmulti / 2,
                    y: offsetY - unit * cmulti / 2
                });
                offsetY -= unit * cmulti;
                offsetX = 0;
            }
            if (i > 10 && i < 20) {
                positions.push({
                    pos: i,
                    x: offsetX + unit/2,
                    y: offsetY - unit / 2
                });
                offsetY -= unit;
            }
            if (i == 20) {
                positions.push({
                    pos: i,
                    x: (unit * cmulti) / 2,
                    y: offsetY - (unit * cmulti) / 2
                });
                offsetX += unit * cmulti;
                offsetY = 0;
            }
            if (i > 20 && i < 30) {
                positions.push({
                    pos: i,
                    x: offsetX + unit / 2,
                    y: (unit * cmulti) / 2
                });
                offsetX += unit;
            }
            if (i == 30) {
                positions.push({
                    pos: i,
                    x: offsetX + unit * 1.7 / 2,
                    y: unit * cmulti / 2
                });
                offsetY += unit * cmulti;
            }
            if (i > 30 && i < 40) {
                positions.push({
                    pos: i,
                    x: offsetX + unit,
                    y: offsetY + unit / 2
                });
                offsetY += unit;
            }
        }
    }

    calcPositions();
    showDots();

    function showDots() {
        for (let i = 0; i < positions.length; i++) {
            let elem = document.getElementById(i);
            if (elem == null) {
                elem = document.createElement("img");
                elem.id = i;
                elem.src = "finger.png";
                elem.style.position = "absolute";
                document.body.appendChild(elem);
            }
            
            elem.style.width = (unit/2)+"px";
            elem.style.height = (unit /2) + "px";
            elem.style.left = positions[i].x + "px";
            elem.style.top = positions[i].y + "px";          
        }
    }

    
})();